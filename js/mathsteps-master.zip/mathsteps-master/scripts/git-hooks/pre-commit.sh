#!/bin/sh

npm test &&
npm run lint
