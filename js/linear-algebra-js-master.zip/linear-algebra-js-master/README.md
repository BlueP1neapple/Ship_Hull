# linear-algebra-js
A Javascript library for all the linear algebra you (don't) remember from class!
