class DimensionError extends Error {
	constructor(message){
		super(message);
	}
}